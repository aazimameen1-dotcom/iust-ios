import WidgetKit
import SwiftUI

/// Port of Android's AttendanceWidgetProvider (compact + full layouts).
/// iOS note: widgets can't do exact 5-min updates — the system rations
/// reloads to ~40-70/day and decides timing. Tapping refresh asks the app
/// to reload timelines; the attendance itself updates when you track it
/// in the app or via Background App Refresh.

struct AttendanceEntry: TimelineEntry {
    let date: Date
    let subjects: [WidgetSubject]
    let updated: Date?
}

struct WidgetSubject: Codable {
    let name: String
    let pct: Double
}

struct AttendanceProvider: TimelineProvider {
    func placeholder(in context: Context) -> AttendanceEntry {
        AttendanceEntry(date: Date(),
                        subjects: [WidgetSubject(name: "Sample Subject", pct: 82)],
                        updated: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (AttendanceEntry) -> Void) {
        completion(loadEntry())
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<AttendanceEntry>) -> Void) {
        let entry = loadEntry()
        // Ask again in 30 min; the system may honor it late when over budget.
        let next = Calendar.current.date(byAdding: .minute, value: 30, to: Date())!
        completion(Timeline(entries: [entry], policy: .after(next)))
    }

    private func loadEntry() -> AttendanceEntry {
        let defaults = UserDefaults(suiteName: "group.com.mussey.iustapp")
        var subjects: [WidgetSubject] = []
        var updated: Date?
        if let data = defaults?.data(forKey: "subjects"),
           let decoded = try? JSONDecoder().decode([WidgetSubject].self, from: data) {
            subjects = decoded
        }
        let ts = defaults?.double(forKey: "updated_at") ?? 0
        if ts > 0 { updated = Date(timeIntervalSince1970: ts) }
        return AttendanceEntry(date: Date(), subjects: subjects, updated: updated)
    }
}

struct AttendanceWidgetView: View {
    var entry: AttendanceEntry
    @Environment(\.widgetFamily) private var family

    private var overall: Double? {
        guard !entry.subjects.isEmpty else { return nil }
        return entry.subjects.map(\.pct).reduce(0, +) / Double(entry.subjects.count)
    }

    private func color(_ pct: Double) -> Color {
        if pct < 75 { return .red }
        if pct < 85 { return .orange }
        return .green
    }

    var body: some View {
        Group {
            if entry.subjects.isEmpty {
                VStack {
                    Text("IUST Attendance")
                        .font(.headline)
                    Text("Open the app → Track attendance")
                        .font(.caption).foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
            } else if family == .systemSmall {
                // Compact layout (port of widget_attendance_compact)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Attendance").font(.caption).bold()
                    if let overall {
                        Text(String(format: "%.1f%%", overall))
                            .font(.title2).bold()
                            .foregroundStyle(color(overall))
                    }
                    if let updated = entry.updated {
                        Text(updated.formatted(date: .abbreviated, time: .shortened))
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
            } else {
                // Full layout (port of widget_attendance)
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("IUST Attendance").font(.headline)
                        Spacer()
                        if let updated = entry.updated {
                            Text(updated.formatted(date: .abbreviated, time: .shortened))
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                    ForEach(entry.subjects.prefix(4), id: \.name) { s in
                        HStack {
                            Text(s.name).font(.caption).lineLimit(1)
                            Spacer()
                            Text(String(format: "%.0f%%", s.pct))
                                .font(.caption).bold()
                                .foregroundStyle(color(s.pct))
                        }
                    }
                    if entry.subjects.count > 4 {
                        Text("+\(entry.subjects.count - 4) more in app")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .containerBackground(.fill.tertiary, for: .widget)
    }
}

@main
struct IUSTWidget: Widget {
    let kind = "IUSTAttendanceWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: AttendanceProvider()) { entry in
            AttendanceWidgetView(entry: entry)
        }
        .configurationDisplayName("IUST Attendance")
        .description("Your attendance at a glance.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}
